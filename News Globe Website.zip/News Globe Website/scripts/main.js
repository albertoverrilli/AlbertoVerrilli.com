// const scene = new THREE.Scene();


// const camera = new THREE.PerspectiveCamera(
//     45,                      // Field of view
//     window.innerWidth / window.innerHeight, // Aspect ratio
//     0.1,                     // Near clipping
//     1000                     // Far clipping
//   );
//   camera.position.set(0, 0, 5); // Move camera away from origin
  